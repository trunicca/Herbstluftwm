#!/bin/sh
hc attr theme.tiling.reset 1
hc attr theme.floating.reset 1
hc set frame_border_width 0
hc set frame_bg_transparent 1
hc set frame_transparent_width 0
hc set frame_gap 0
hc set always_show_frame 0

hc set window_gap 10
hc set frame_padding 0
hc set smart_window_surroundings 0
hc set smart_frame_surroundings 0
hc set mouse_recenter_gap 0
hc set focus_follows_mouse 1

hc attr theme.tiling.outer_color '#000000'
hc attr theme.floating.outer_color '#000000'
hc attr theme.active.outer_color '#000000'
hc attr theme.active.color '#e1485a'
hc attr theme.normal.color '#f5f5f5'
hc attr theme.urgent.color '#c81a71'
hc attr theme.outer_width 3
hc attr theme.border_width 6
